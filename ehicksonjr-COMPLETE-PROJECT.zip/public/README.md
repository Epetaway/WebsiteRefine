# Earl Hickson Jr. Portfolio - Static Assets
